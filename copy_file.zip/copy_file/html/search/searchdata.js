var indexSectionsWithContent =
{
  0: "adgmpqrt",
  1: "adgmpqrt",
  2: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};


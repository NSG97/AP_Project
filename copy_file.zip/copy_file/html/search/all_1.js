var searchData=
[
  ['database',['Database',['../class_database.html',1,'']]],
  ['dblp_5fparser',['DBLP_Parser',['../class_d_b_l_p___parser.html',1,'']]]
];

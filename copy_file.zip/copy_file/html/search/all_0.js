var searchData=
[
  ['authorsearchparser',['AuthorSearchParser',['../class_author_search_parser.html',1,'']]],
  ['ap_5fproject',['AP_Project',['../md__r_e_a_d_m_e.html',1,'']]]
];

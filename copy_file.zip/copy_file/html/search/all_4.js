var searchData=
[
  ['resultpanel',['ResultPanel',['../class_result_panel.html',1,'']]]
];

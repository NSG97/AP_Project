var searchData=
[
  ['resultdatabase',['ResultDatabase',['../class_result_database.html',1,'']]],
  ['resultpanel',['ResultPanel',['../class_result_panel.html',1,'']]]
];
